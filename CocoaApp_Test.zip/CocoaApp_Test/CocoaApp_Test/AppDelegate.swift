//
//  AppDelegate.swift
//  CocoaApp_Test
//
//  Created by Poorna Chander Kalidas on 2017-07-23.
//  Copyright © 2017 Poorna Chander Kalidas. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

